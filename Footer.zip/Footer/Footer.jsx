import React from "react";
import styles from "./Footer.module.css";

const Footer = () => {
  
  return (
    <div className={styles.Footer}>
      <div className={styles.links_left}>
        <div>social media</div>
        <img src="/Footer/facebook.svg" className={styles.social} alt="facebook" />

        <img src="/Footer/instagram.svg" className={styles.social} alt="instagram" />

         <img src="/Footer/twitter.svg" className={styles.social} alt="twitter" />
        <div>e-mail:</div>

        <div>amnyamteam@gmail.com</div>
      </div>
      <img src="/Footer/footer.svg" className={styles.logo} alt="logo" />
      <div className={styles.links_right}>
        <div>learn more</div>
        <div>about us</div>
      </div>
    </div>
  )
}

export default Footer;